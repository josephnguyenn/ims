<?php
if (!defined('BASE_URL')) {
    define('BASE_URL', (getenv('APP_URL') ?: 'http://localhost') . '/ims/public');
}
?>
